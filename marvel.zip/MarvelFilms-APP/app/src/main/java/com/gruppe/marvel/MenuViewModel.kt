package com.gruppe.marvel

import android.arch.lifecycle.ViewModel

class MenuViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}